# pyqir_parser

Under active development and will be updated.

## Building and Testing

See [Building](../docs/building.md)

## Limitations

- Unsupported IR
  - Phi nodes
  - arrays
